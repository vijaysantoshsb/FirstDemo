package com.android.koindemo

import android.app.Application
import com.android.koindemo.loginviewmodel.LoginViewmodel
import com.android.koindemo.loginviewmodel.RegistartionViewmodel
import com.android.koindemo.presenters.LoginRepository
import com.android.koindemo.presenters.RegistrationRepository
import com.android.koindemo.repository.LoginRepositoryImpl
import com.android.koindemo.repository.RegistrationRepoImpl
import org.koin.android.viewmodel.dsl.viewModel
import org.koin.dsl.module

val appModule = module {

    // single instance of HelloRepository
    single<LoginRepository> { LoginRepositoryImpl() }

    // MyViewModel ViewModel
    viewModel { LoginViewmodel(get()) }

    single<RegistrationRepository> { RegistrationRepoImpl() }

    viewModel { RegistartionViewmodel(get()) }
}