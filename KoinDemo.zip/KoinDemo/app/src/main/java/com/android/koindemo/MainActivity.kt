package com.android.koindemo

import android.arch.lifecycle.ViewModel
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.android.koindemo.loginviewmodel.LoginViewmodel
import com.android.koindemo.loginviewmodel.RegistartionViewmodel
import com.android.koindemo.repository.LoginRepositoryImpl
import org.koin.android.ext.android.inject
import org.koin.android.viewmodel.ext.android.viewModel

class MainActivity : AppCompatActivity() {

    val loginViewmodel : LoginViewmodel by viewModel()

    val registrationviewModel : RegistartionViewmodel by viewModel()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val data = loginViewmodel.sayHello()
        Log.i("data", data)


        val registrationData = registrationviewModel.data()
        Log.i("data", registrationData)
    }
}
