package com.android.koindemo.loginviewmodel

import android.arch.lifecycle.ViewModel
import com.android.koindemo.presenters.LoginRepository
import com.android.koindemo.repository.LoginRepositoryImpl

class LoginViewmodel(val repo : LoginRepository) : ViewModel() {

    fun sayHello() = "${repo.getLoginData()} from $this"
}