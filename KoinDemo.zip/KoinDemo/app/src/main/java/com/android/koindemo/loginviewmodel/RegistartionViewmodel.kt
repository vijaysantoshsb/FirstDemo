package com.android.koindemo.loginviewmodel

import android.arch.lifecycle.ViewModel
import com.android.koindemo.presenters.RegistrationRepository

class RegistartionViewmodel(val instance : RegistrationRepository) : ViewModel(){
    fun data() = instance.getRegistrationData()
}