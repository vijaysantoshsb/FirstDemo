package com.android.koindemo.presenters

interface LoginRepository {
    fun getLoginData() : String
}