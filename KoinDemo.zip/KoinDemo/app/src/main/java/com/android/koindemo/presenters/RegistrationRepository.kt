package com.android.koindemo.presenters

interface RegistrationRepository{
    fun getRegistrationData() : String
}