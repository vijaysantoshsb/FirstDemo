package com.android.koindemo.repository

import com.android.koindemo.presenters.LoginRepository

class LoginRepositoryImpl : LoginRepository{
    override fun getLoginData(): String {
        return "My Darling"
    }
}