package com.android.koindemo.repository

import com.android.koindemo.presenters.RegistrationRepository

class RegistrationRepoImpl : RegistrationRepository {
    override fun getRegistrationData() : String {
        return "MY Hoona"
    }
}